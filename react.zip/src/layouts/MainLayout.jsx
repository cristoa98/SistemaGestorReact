// src/layouts/MainLayout.jsx
import { Navbar, Nav, Container, Card } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";
import { Outlet } from "react-router-dom";

export default function MainLayout() {
    return (
        <>
            {/* Header */}
            <Navbar expand="lg" style={{ backgroundColor: "var(--c-dark-1)" }} className="justify-content-center">
                <Container className="justify-content-center">
                    <Navbar.Brand className="fw-bold text-uppercase" >
                        Gestor Local
                    </Navbar.Brand>
                </Container>
            </Navbar>

            {/* Tabs */}
            <Navbar expand="lg" style={{ backgroundColor: "var(--c-dark-2)" }}>
                <Container fluid="xxl">
                    <Navbar.Toggle aria-controls="mainNav" />
                    <Navbar.Collapse id="mainNav">
                        <Nav className="me-auto nav-pills">
                            <LinkContainer to="/" end><Nav.Link >Inicio</Nav.Link></LinkContainer>
                            <LinkContainer to="/solicitudes"><Nav.Link >Solicitudes</Nav.Link></LinkContainer>
                            <LinkContainer to="/inventario"><Nav.Link >Inventario</Nav.Link></LinkContainer>
                            <LinkContainer to="/prestamos"><Nav.Link >Préstamos</Nav.Link></LinkContainer>
                            <LinkContainer to="/trazabilidad"><Nav.Link >Trazabilidad</Nav.Link></LinkContainer>
                            <LinkContainer to="/reportes"><Nav.Link >Reportes</Nav.Link></LinkContainer>
                            <LinkContainer to="/usuarios"><Nav.Link >Usuarios</Nav.Link></LinkContainer>
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            {/* Body */}
            <div className="py-4" style={{ backgroundColor: "var(--c-mid)" }}>
                <Container fluid="xxl">
                    <Card className="shadow-lg border-0" style={{ borderRadius: "var(--radius-2xl)", backgroundColor: "var(--white)" }}>
                        <Card.Body className="p-4 p-md-5">
                            <Outlet />
                        </Card.Body>
                    </Card>
                </Container>
            </div>

            {/* Footer bar */}
            <div style={{ backgroundColor: "var(--c-dark-1)", height: 24 }} />
        </>
    );
}
