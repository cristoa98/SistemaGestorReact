import { demoResources } from './data';

// Simula "latencia" mínima y retorna copias inmutables
function delay(ms = 200) {
    return new Promise(res => setTimeout(res, ms));
}

export async function getFeaturedResources() {
    await delay();
    return demoResources.filter(x => x.featured).map(x => ({ ...x }));
}

export async function getLowStock() {
    await delay();
    return demoResources
        .filter(x => x.stockLevel === 'bajo' || x.stockLevel === 'critico')
        .map(x => ({ ...x }));
}

export async function getAllResources() {
    await delay();
    return demoResources.map(x => ({ ...x }));
}
