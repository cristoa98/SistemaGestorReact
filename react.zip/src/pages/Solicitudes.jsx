import React, {
    useCallback,
    useEffect,
    useMemo,
    useState,
} from "react";
import {
    Form,
    Button,
    Table,
    Badge,
    ButtonGroup,
    Alert,
    Spinner,
} from "react-bootstrap";
import FormTableShell from "../components/FormTableShell";
import { useApi } from "../hooks/useApi";
import { useAuth } from "../context/AuthContext";

const emptyForm = {
    nombre: "",
    correo: "",
    itemId: "",
    cantidad: 1,
    fechaUso: "",
    observacion: "",
};

function normalizeItem(raw) {
    return {
        id: raw._id || raw.id,
        descripcion: raw.descripcion || "",
    };
}

function estadoVariant(estado) {
    switch (estado) {
        case "APROBADA":
            return "success";
        case "RECHAZADA":
            return "danger";
        case "ENTREGADA":
            return "info";
        case "CERRADA":
            return "secondary";
        default:
            return "warning"; // PENDIENTE u otro
    }
}

function normalizeRequest(raw, itemsMap) {
    const itemId = raw.item?._id || raw.itemId || raw.item;
    const item =
        raw.item ||
        itemsMap[itemId] || {
            descripcion: raw.itemNombre || "No especificado",
        };

    return {
        id: raw._id || raw.id,
        nombre: raw.nombre || raw.persona || "",
        correo: raw.correo || "",
        itemId,
        itemNombre: item.descripcion,
        cantidad: Number(raw.cantidad ?? 0) || 0,
        fechaUso: raw.fechaUso
            ? String(raw.fechaUso).slice(0, 10)
            : "",
        estado: raw.estado || "PENDIENTE",
        observacion: raw.observacion || raw.motivo || "",
        creado:
            raw.createdAt || raw.fechaSolicita
                ? String(raw.createdAt || raw.fechaSolicita).slice(0, 10)
                : "",
    };
}

export default function Solicitudes() {
    const { api } = useApi();
    const { token, isAuthenticated } = useAuth();

    const [items, setItems] = useState([]);
    const [rows, setRows] = useState([]);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState(null);
    const [flash, setFlash] = useState(null);
    const [filter, setFilter] = useState("");
    const [selectedId, setSelectedId] = useState(null);
    const [form, setForm] = useState(emptyForm);

    const loadData = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);

            const [itemsResp, reqsResp] = await Promise.all([
                api("/items"),
                api("/requests"),
            ]);

            const normalizedItems = itemsResp.map(normalizeItem);
            setItems(normalizedItems);

            const itemsMap = Object.fromEntries(
                normalizedItems.map((i) => [i.id, i])
            );

            const normalizedReqs = reqsResp.map((r) =>
                normalizeRequest(r, itemsMap)
            );
            setRows(normalizedReqs);
        } catch (err) {
            setError(err.message || "Error al cargar solicitudes.");
        } finally {
            setLoading(false);
        }
    }, [api]);

    useEffect(() => {
        loadData();
    }, [loadData]);

    const selected = rows.find((r) => r.id === selectedId) || null;

    const filteredRows = useMemo(() => {
        if (!filter.trim()) return rows;
        const q = filter.toLowerCase();
        return rows.filter(
            (r) =>
                r.nombre.toLowerCase().includes(q) ||
                r.correo.toLowerCase().includes(q) ||
                r.itemNombre.toLowerCase().includes(q) ||
                r.estado.toLowerCase().includes(q)
        );
    }, [rows, filter]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm((f) => ({ ...f, [name]: value }));
    };

    const resetForm = () => {
        setSelectedId(null);
        setForm(emptyForm);
        setFlash(null);
    };

    const handleSelect = (row) => {
        setSelectedId(row.id);
        setForm({
            nombre: row.nombre,
            correo: row.correo,
            itemId: row.itemId || "",
            cantidad: row.cantidad,
            fechaUso: row.fechaUso,
            observacion: row.observacion,
        });
        setFlash(null);
    };

    const validateForm = () => {
        if (!form.nombre.trim()) {
            return "El nombre del solicitante es obligatorio.";
        }
        if (!form.itemId) {
            return "Debes seleccionar un equipo.";
        }
        const cantidad = Number(form.cantidad);
        if (!cantidad || cantidad <= 0) {
            return "La cantidad debe ser un número mayor a 0.";
        }
        return null;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setFlash(null);

        const msg = validateForm();
        if (msg) {
            setFlash({ type: "danger", msg });
            return;
        }

        const payload = {
            nombre: form.nombre.trim(),
            correo: form.correo.trim(),
            item: form.itemId,
            cantidad: Number(form.cantidad) || 0,
            fechaUso: form.fechaUso || null,
            observacion: form.observacion.trim(),
        };

        try {
            setSaving(true);
            if (selectedId) {
                if (!token) {
                    setFlash({
                        type: "warning",
                        msg: "Debes iniciar sesión para editar una solicitud.",
                    });
                    return;
                }
                await api(`/requests/${selectedId}`, {
                    method: "PUT",
                    body: payload,
                });
                setFlash({
                    type: "success",
                    msg: "Solicitud actualizada correctamente.",
                });
            } else {
                await api("/requests", {
                    method: "POST",
                    body: payload,
                });
                setFlash({
                    type: "success",
                    msg: "Solicitud enviada correctamente.",
                });
            }

            resetForm();
            await loadData();
        } catch (err) {
            setFlash({
                type: "danger",
                msg: err.message || "No se pudo guardar la solicitud.",
            });
        } finally {
            setSaving(false);
        }
    };

    const ensureAuth = () => {
        if (!token) {
            setFlash({
                type: "warning",
                msg: "Debes iniciar sesión para gestionar el estado de las solicitudes.",
            });
            return false;
        }
        return true;
    };

    const updateEstado = async (row, nuevoEstado) => {
        if (!ensureAuth()) return;
        try {
            setSaving(true);
            await api(`/requests/${row.id}/status`, {
                method: "PATCH",
                body: { estado: nuevoEstado },
            });
            setFlash({
                type: "success",
                msg: `Estado actualizado a ${nuevoEstado}.`,
            });
            await loadData();
        } catch (err) {
            setFlash({
                type: "danger",
                msg: err.message || "No se pudo actualizar el estado.",
            });
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async () => {
        if (!selectedId) return;
        if (!ensureAuth()) return;

        if (
            !window.confirm(
                "¿Eliminar la solicitud seleccionada? Esta acción es irreversible."
            )
        ) {
            return;
        }

        try {
            setSaving(true);
            await api(`/requests/${selectedId}`, { method: "DELETE" });
            setFlash({ type: "info", msg: "Solicitud eliminado." });
            resetForm();
            await loadData();
        } catch (err) {
            setFlash({
                type: "danger",
                msg: err.message || "No se pudo eliminar la solicitud.",
            });
        } finally {
            setSaving(false);
        }
    };

    const left = (
        <Form onSubmit={handleSubmit}>
            {flash && (
                <Alert
                    variant={flash.type}
                    onClose={() => setFlash(null)}
                    dismissible
                    className="py-2"
                >
                    {flash.msg}
                </Alert>
            )}

            <Form.Group className="mb-3" controlId="solNombre">
                <Form.Label>Nombre solicitante *</Form.Label>
                <Form.Control
                    name="nombre"
                    value={form.nombre}
                    onChange={handleChange}
                    placeholder="Ej: Juan Pérez"
                    required
                />
            </Form.Group>

            <Form.Group className="mb-3" controlId="solCorreo">
                <Form.Label>Correo de contacto</Form.Label>
                <Form.Control
                    type="email"
                    name="correo"
                    value={form.correo}
                    onChange={handleChange}
                    placeholder="Ej: juan@ejemplo.cl"
                />
            </Form.Group>

            <Form.Group className="mb-3" controlId="solItem">
                <Form.Label>Equipo / recurso *</Form.Label>
                <Form.Select
                    name="itemId"
                    value={form.itemId}
                    onChange={handleChange}
                    required
                >
                    <option value="">Selecciona un equipo...</option>
                    {items.map((i) => (
                        <option key={i.id} value={i.id}>
                            {i.descripcion}
                        </option>
                    ))}
                </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3" controlId="solCantidad">
                <Form.Label>Cantidad *</Form.Label>
                <Form.Control
                    type="number"
                    min={1}
                    name="cantidad"
                    value={form.cantidad}
                    onChange={handleChange}
                    required
                />
            </Form.Group>

            <Form.Group className="mb-3" controlId="solFecha">
                <Form.Label>Fecha de uso</Form.Label>
                <Form.Control
                    type="date"
                    name="fechaUso"
                    value={form.fechaUso}
                    onChange={handleChange}
                />
            </Form.Group>

            <Form.Group className="mb-3" controlId="solObs">
                <Form.Label>Detalle / observaciones</Form.Label>
                <Form.Control
                    as="textarea"
                    rows={2}
                    name="observacion"
                    value={form.observacion}
                    onChange={handleChange}
                />
            </Form.Group>

            <ButtonGroup className="d-flex gap-2">
                <Button type="submit" disabled={saving}>
                    {selectedId ? "Actualizar" : "Enviar"} solicitud
                </Button>
                <Button
                    type="button"
                    variant="secondary"
                    onClick={resetForm}
                    disabled={saving}
                >
                    Nueva
                </Button>
                <Button
                    type="button"
                    variant="outline-danger"
                    onClick={handleDelete}
                    disabled={!selectedId || saving}
                >
                    Eliminar
                </Button>
            </ButtonGroup>

            {selected && (
                <p className="mt-2 small text-muted">
                    Editando solicitud de <strong>{selected.nombre}</strong> (
                    {selected.itemNombre})
                </p>
            )}
        </Form>
    );

    const right = (
        <>
            <div className="d-flex justify-content-between align-items-center mb-3 gap-2">
                <Form.Control
                    placeholder="Buscar por nombre, equipo, correo o estado..."
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                />
            </div>

            {error && (
                <Alert
                    variant="danger"
                    onClose={() => setError(null)}
                    dismissible
                    className="py-2"
                >
                    {error}
                </Alert>
            )}

            {loading ? (
                <div className="d-flex justify-content-center py-4">
                    <Spinner animation="border" role="status" size="sm" className="me-2" />
                    <span>Cargando solicitudes...</span>
                </div>
            ) : (
                <Table hover responsive className="align-middle mb-0">
                    <thead>
                        <tr>
                            <th style={{ width: 40 }}>#</th>
                            <th>Fecha</th>
                            <th>Solicitante</th>
                            <th>Equipo</th>
                            <th className="text-end">Cant.</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                            <th>Observaciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredRows.length === 0 ? (
                            <tr>
                                <td colSpan={8} className="text-center text-muted py-4">
                                    No hay solicitudes registradas.
                                </td>
                            </tr>
                        ) : (
                            filteredRows.map((r, idx) => (
                                <tr
                                    key={r.id}
                                    onClick={() => handleSelect(r)}
                                    style={{ cursor: "pointer" }}
                                    className={selectedId === r.id ? "table-active" : ""}
                                >
                                    <td>{idx + 1}</td>
                                    <td className="small">{r.creado || r.fechaUso}</td>
                                    <td>
                                        <div>{r.nombre}</div>
                                        <div className="small text-muted">{r.correo}</div>
                                    </td>
                                    <td>{r.itemNombre}</td>
                                    <td className="text-end">{r.cantidad}</td>
                                    <td>
                                        <Badge bg={estadoVariant(r.estado)}>{r.estado}</Badge>
                                    </td>
                                    <td>
                                        <ButtonGroup size="sm">
                                            <Button
                                                variant="outline-success"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    updateEstado(r, "APROBADA");
                                                }}
                                                disabled={saving || r.estado === "APROBADA"}
                                            >
                                                Aprobar
                                            </Button>
                                            <Button
                                                variant="outline-danger"
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    updateEstado(r, "RECHAZADA");
                                                }}
                                                disabled={saving || r.estado === "RECHAZADA"}
                                            >
                                                Rechazar
                                            </Button>
                                        </ButtonGroup>
                                    </td>
                                    <td className="small text-muted">{r.observacion}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </Table>
            )}
        </>
    );

    return (
        <FormTableShell
            leftTitle="Nueva solicitud"
            rightTitle="Solicitudes registradas"
            left={left}
            right={right}
            leftMd={5}
            rightMd={7}
        />
    );
}
